﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaAndPerimeterOneal
{
    public partial class frmAreaPerimeter : Form
    {
        public frmAreaPerimeter()
        {
            InitializeComponent();
        }

        private void lblLength_Click(object sender, EventArgs e)
        {

        }

        private void lblWidth_Click(object sender, EventArgs e)
        {

        }

        private void txtLength_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCaculate_Click(object sender, EventArgs e)
        {

        }

        private void mnuFile_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void frmAreaPerimeter_Load(object sender, EventArgs e)
        {
            this.lblPerimeter.Hide();
            this.lblArea.Hide();
            this.lblAnswerPerimeter.Hide();
            this.lblAnswerArea.Hide();
        }
    }
}
